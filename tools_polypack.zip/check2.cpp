#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <utility>
#include <vector>
#include <cmath>

using namespace std;

static inline pair<long long,long long> rot90cw(long long x, long long y, int r) {
    switch (r & 3) {
        case 0:  return { x,  y};
        case 1:  return { y, -x};
        case 2:  return {-x, -y};
        default: return {-y,  x};
    }
}

// Normalize coordinates so min x = min y = 0, then sort
template <class V>
static vector<pair<long long,long long>> normalizeCoords(const V& pts) {
    long long minx = numeric_limits<long long>::max();
    long long miny = numeric_limits<long long>::max();
    for (auto &p : pts) {
        minx = min(minx, (long long)p.first);
        miny = min(miny, (long long)p.second);
    }
    vector<pair<long long,long long>> out;
    out.reserve(pts.size());
    for (auto &p : pts) out.push_back({(long long)p.first - minx, (long long)p.second - miny});
    sort(out.begin(), out.end());
    return out;
}

[[noreturn]] void fail(const string &msg) {
    // "Wrong Answer" style
    cout << "WA: " << msg << "\n";
    exit(1);
}

[[noreturn]] void ok(double score, long long totalCells, long long W, long long H, long long area, int k_max) {
    cout.setf(ios::fixed);
    cout.precision(9);
    cout << "OK: Score = " << score
         << "  (cells=" << totalCells
         << ", W=" << W
         << ", H=" << H
         << ", area=" << area
         << ", K_max=" << k_max << ")\n";
    exit(0);
}

bool hasExtraNonWhitespace(ifstream &in) {
    // Check if there is any non-whitespace token left
    streampos pos = in.tellg();
    if (!in.good()) return false;
    string dummy;
    if (in >> dummy) {
        return true;
    }
    // restore position (not strictly necessary, we exit on extra anyway)
    in.clear();
    in.seekg(pos);
    return false;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " instance.txt output.txt\n";
        return 1;
    }

    ifstream inf(argv[1]);
    ifstream ouf(argv[2]);
    if (!inf) {
        cerr << "Could not open instance file: " << argv[1] << "\n";
        return 1;
    }
    if (!ouf) {
        cerr << "Could not open output file: " << argv[2] << "\n";
        return 1;
    }

    // ===== Read input (the instance) =====
    int n;
    if (!(inf >> n)) fail("Failed to read n");
    if (n < 1 || n > 100000) fail("n out of range [1, 100000]");

    vector<vector<pair<long long,long long>>> shapes(n);
    long long totalCells = 0;
    int k_max = 0;

    for (int i = 0; i < n; ++i) {
        int k;
        if (!(inf >> k)) fail("Failed to read k_i for piece " + to_string(i+1));
        if (k < 1 || k > 15) fail("k_i out of range [1, 15] for piece " + to_string(i+1));

        k_max = max(k_max, k);
        shapes[i].reserve(k);
        for (int j = 0; j < k; ++j) {
            long long x, y;
            if (!(inf >> x >> y)) {
                fail("Failed to read coordinates for piece " + to_string(i+1));
            }
            shapes[i].push_back({x, y});
        }
        totalCells += (long long)shapes[i].size();
    }

    // ===== Read participant output (matrix) =====
    long long W, H;
    if (!(ouf >> W >> H)) {
        fail("Failed to read W and H from output");
    }

    if (W < 1 || W > (long long)4e12) fail("W out of range [1, 4e12]");
    if (H < 1 || H > (long long)4e12) fail("H out of range [1, 4e12]");

    if (W > (long long)2e7 || H > (long long)2e7) {
        fail("W or H too large for matrix parsing (sanity guard)");
    }

    // Hard cap to avoid pathological outputs that are impractical to read in checker.
    // Adjust if your environment supports larger I/O.
    if (W > 0 && H > 0 && W > (long long)2e8 / H) {
        fail("W*H too large for checker I/O; got " + to_string(W) + " x " + to_string(H));
    }

    long long WH = W * H; // safe due to the above check

    // Collect cells per piece ID
    vector<vector<pair<long long,long long>>> assigned(n);
    long long nonZeroCells = 0;

    for (long long r = 0; r < H; ++r) {
        for (long long c = 0; c < W; ++c) {
            long long id;
            if (!(ouf >> id)) {
                fail("Not enough grid entries; expected " + to_string(WH) + " IDs");
            }
            if (id < 0 || id > n) {
                fail("grid_id out of range [0, n]");
            }
            if (id == 0) continue;
            assigned[(int)id - 1].push_back({c, r}); // x=c, y=r
            ++nonZeroCells;
        }
    }

    // Check for extra data after grid
    if (hasExtraNonWhitespace(ouf)) {
        fail("Extra data after the HxW grid");
    }

    // Quick count check: total non-zero must equal totalCells
    if (nonZeroCells != totalCells) {
        fail("Sum of labeled cells (" + to_string(nonZeroCells) +
             ") does not match Σk_i (" + to_string(totalCells) + ")");
    }

    // ===== Check each piece against allowed transforms =====
    for (int i = 0; i < n; ++i) {
        const auto& base = shapes[i];
        const long long need = (long long)base.size();

        if ((long long)assigned[i].size() != need) {
            fail("Piece " + to_string(i+1) + " has " +
                 to_string((long long)assigned[i].size()) +
                 " cells in output, expected " + to_string(need));
        }

        // Normalize the assigned set
        auto assignedNorm = normalizeCoords(assigned[i]);

        bool matched = false;

        for (int F = 0; F <= 1 && !matched; ++F) {
            for (int R = 0; R < 4 && !matched; ++R) {
                vector<pair<long long,long long>> trans;
                trans.reserve(base.size());
                for (auto &p : base) {
                    long long x = p.first, y = p.second;
                    if (F == 1) x = -x;              // reflect across y-axis
                    auto pr = rot90cw(x, y, R);      // rotate CW
                    x = pr.first;
                    y = pr.second;
                    trans.push_back({x, y});
                }
                auto variantNorm = normalizeCoords(trans);

                if (variantNorm.size() == assignedNorm.size() &&
                    equal(variantNorm.begin(), variantNorm.end(), assignedNorm.begin())) {
                    matched = true;
                }
            }
        }

        if (!matched) {
            // Provide a small diagnostic: report first few assigned cells
            string sample;
            int limit = (int)min<long long>(assigned[i].size(), 5);
            for (int t = 0; t < limit; ++t) {
                if (t) sample += "; ";
                sample += "(" + to_string(assigned[i][t].first) + "," +
                          to_string(assigned[i][t].second) + ")";
            }
            fail("Piece " + to_string(i+1) +
                 " cells do not match any allowed transform of its shape. "
                 "Example cells: " + sample);
        }
    }

    // ===== Scoring =====
    if (W <= 0 || H <= 0) {
        fail("Non-positive area (W*H)");
    }

    long long area = W * H;
    double score = 100000.0 * (double)totalCells / (double)area;

    ok(score, totalCells, W, H, area, k_max);
}

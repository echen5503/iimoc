#include <bits/stdc++.h>
#include <filesystem>

using namespace std;

using Cell = pair<int,int>;
using Shape = vector<Cell>;
using ShapeSet = set<Shape>; // canonical shapes

const array<Cell,4> DIRS4 = {{{1,0}, {-1,0}, {0,1}, {0,-1}}};

// ---------- Helpers ----------

Shape normalize(const vector<Cell>& cells) {
    int minx = INT_MAX, miny = INT_MAX;
    for (auto &p : cells) {
        minx = min(minx, p.first);
        miny = min(miny, p.second);
    }
    Shape norm;
    norm.reserve(cells.size());
    for (auto &p : cells) {
        norm.push_back({p.first - minx, p.second - miny});
    }
    sort(norm.begin(), norm.end());
    return norm;
}

inline Cell rot90cw(const Cell& c) {
    // (x,y) -> (y,-x)
    return {c.second, -c.first};
}

inline Cell reflect_y(const Cell& c) {
    // (x,y) -> (-x,y)
    return {-c.first, c.second};
}

Shape canonical_D4(const Shape& shape) {
    vector<Shape> variants;
    variants.reserve(8);

    vector<Cell> base = shape;
    for (int f = 0; f < 2; ++f) {
        vector<Cell> pts;
        pts.reserve(base.size());
        if (f == 1) {
            for (auto &p : base) pts.push_back(reflect_y(p));
        } else {
            pts = base;
        }
        vector<Cell> cur = pts;
        for (int r = 0; r < 4; ++r) {
            if (r > 0) {
                for (auto &p : cur) p = rot90cw(p);
            }
            variants.push_back(normalize(cur));
        }
    }
    Shape best = variants[0];
    for (size_t i = 1; i < variants.size(); ++i) {
        if (variants[i] < best) best = variants[i];
    }
    return best;
}

vector<Cell> border_neighbors(const Shape& shape) {
    struct HashPair {
        size_t operator()(const Cell& c) const noexcept {
            return (static_cast<size_t>(c.first) << 32) ^ static_cast<size_t>(c.second);
        }
    };

    unordered_set<Cell, HashPair> S;
    S.reserve(shape.size() * 2);
    for (auto &p : shape) S.insert(p);

    unordered_set<Cell, HashPair> nbrs;
    nbrs.reserve(shape.size() * 4);

    for (auto &p : shape) {
        for (auto &d : DIRS4) {
            Cell q{p.first + d.first, p.second + d.second};
            if (!S.count(q)) nbrs.insert(q);
        }
    }

    vector<Cell> res;
    res.reserve(nbrs.size());
    for (auto &p : nbrs) res.push_back(p);
    return res;
}

// ---------- Hole-free test ----------

bool is_hole_free(const Shape& shape) {
    if (shape.empty()) return true;

    struct HashPair {
        size_t operator()(const Cell& c) const noexcept {
            return (static_cast<size_t>(c.first) << 32) ^ static_cast<size_t>(c.second);
        }
    };

    unordered_set<Cell, HashPair> S;
    S.reserve(shape.size() * 2);
    vector<int> xs, ys;
    xs.reserve(shape.size());
    ys.reserve(shape.size());

    for (auto &p : shape) {
        S.insert(p);
        xs.push_back(p.first);
        ys.push_back(p.second);
    }

    int minx = *min_element(xs.begin(), xs.end()) - 1;
    int maxx = *max_element(xs.begin(), xs.end()) + 1;
    int miny = *min_element(ys.begin(), ys.end()) - 1;
    int maxy = *max_element(ys.begin(), ys.end()) + 1;

    unordered_set<Cell, HashPair> ext;
    ext.reserve((maxx-minx+1) * 2 + (maxy-miny+1) * 2);

    queue<Cell> q;
    auto try_add = [&](int x, int y) {
        Cell c{x,y};
        if (!S.count(c) && !ext.count(c)) {
            ext.insert(c);
            q.push(c);
        }
    };

    for (int x = minx; x <= maxx; ++x) {
        try_add(x, miny);
        try_add(x, maxy);
    }
    for (int y = miny; y <= maxy; ++y) {
        try_add(minx, y);
        try_add(maxx, y);
    }

    while (!q.empty()) {
        Cell cur = q.front(); q.pop();
        for (auto &d : DIRS4) {
            int nx = cur.first + d.first;
            int ny = cur.second + d.second;
            if (nx < minx || nx > maxx || ny < miny || ny > maxy) continue;
            Cell nxt{nx, ny};
            if (S.count(nxt) || ext.count(nxt)) continue;
            ext.insert(nxt);
            q.push(nxt);
        }
    }

    for (int x = minx + 1; x < maxx; ++x) {
        for (int y = miny + 1; y < maxy; ++y) {
            Cell c{x,y};
            if (!S.count(c) && !ext.count(c)) {
                return false; // interior hole
            }
        }
    }
    return true;
}

// ---------- Enumeration ----------

vector<vector<Shape>> enumerate_free_polyominoes(int maxK) {
    vector<ShapeSet> size_classes(maxK);
    size_classes[0].insert(Shape{{0,0}}); // size 1

    for (int k = 2; k <= maxK; ++k) {
        ShapeSet newset;
        for (const auto &poly : size_classes[k-2]) {
            auto nbrs = border_neighbors(poly);
            for (auto &q : nbrs) {
                vector<Cell> S(poly.begin(), poly.end());
                S.push_back(q);
                Shape canon = canonical_D4(S);
                newset.insert(std::move(canon));
            }
        }
        size_classes[k-1] = std::move(newset);
        cerr << "[info] k=" << k << " count=" << size_classes[k-1].size() << "\n";
    }

    vector<vector<Shape>> result(maxK);
    for (int k = 1; k <= maxK; ++k) {
        result[k-1].reserve(size_classes[k-1].size());
        for (const auto &sh : size_classes[k-1]) {
            result[k-1].push_back(sh);
        }
    }
    return result;
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int maxK = 15;
    string outFile = "hole_free_polyominoes_1_15.txt";
    if (argc >= 2) outFile = argv[1];  // optional: custom filename

    cerr << "[info] enumerating free polyominoes up to size " << maxK << "...\n";
    auto all_by_size = enumerate_free_polyominoes(maxK);

    cerr << "[info] filtering hole-free...\n";
    vector<vector<Shape>> hf_by_size;
    hf_by_size.reserve(all_by_size.size());
    long long total_hf = 0;
    for (int k = 1; k <= maxK; ++k) {
        vector<Shape> v;
        for (const auto &sh : all_by_size[k-1]) {
            if (is_hole_free(sh)) v.push_back(sh);
        }
        total_hf += static_cast<long long>(v.size());
        cerr << "  size " << k << ": " << v.size() << " hole-free\n";
        hf_by_size.push_back(std::move(v));
    }

    cerr << "[info] total hole-free shapes = " << total_hf << "\n";
    cerr << "[info] writing to " << outFile << "...\n";

    ofstream fout(outFile);
    if (!fout) {
        cerr << "Error opening output file: " << outFile << "\n";
        return 1;
    }

    // One shape per line: k x0 y0 x1 y1 ... x(k-1) y(k-1)
    for (int k = 1; k <= maxK; ++k) {
        for (const auto &sh : hf_by_size[k-1]) {
            fout << k;
            for (auto &p : sh) {
                fout << ' ' << p.first << ' ' << p.second;
            }
            fout << '\n';
        }
    }

    cerr << "[info] done.\n";
    return 0;
}

#include <bits/stdc++.h>
#include <filesystem>

using namespace std;

using Cell  = pair<int,int>;
using Shape = vector<Cell>;

struct Args {
    int count = 100;
    string out = "testdata";
    long long seed = 1000;
    string shapes_file = "hole_free_polyominoes_1_15.txt";
};

Args parse_args(int argc, char** argv) {
    Args args;
    for (int i = 1; i < argc; ++i) {
        string a = argv[i];
        auto get_val = [&](int &i)->string {
            if (i + 1 >= argc) {
                throw runtime_error("Missing value for argument: " + a);
            }
            return string(argv[++i]);
        };
        if (a == "--count") {
            args.count = stoi(get_val(i));
        } else if (a == "--out") {
            args.out = get_val(i);
        } else if (a == "--seed") {
            args.seed = stoll(get_val(i));
        } else if (a == "--shapes") {
            args.shapes_file = get_val(i);
        } else if (a == "--help" || a == "-h") {
            cout << "Usage: " << argv[0]
                 << " [--count N] [--out DIR] [--seed S] [--shapes FILE]\n";
            exit(0);
        } else {
            cerr << "Unknown argument: " << a << "\n";
            exit(1);
        }
    }
    return args;
}

// ---------- Read polyominoes file ----------
// Format: one line per shape
//   k x0 y0 x1 y1 ... x(k-1) y(k-1)

vector<vector<Shape>> read_poly_file(const string &fname, int &maxSizeFound) {
    ifstream fin(fname);
    if (!fin) {
        throw runtime_error("Failed to open shapes file: " + fname);
    }

    vector<vector<Shape>> by_size;  // index by size

    string line;
    maxSizeFound = 0;
    while (std::getline(fin, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        int k;
        if (!(ss >> k)) continue;
        vector<int> vals;
        vals.reserve(2 * k);
        int x;
        while (ss >> x) vals.push_back(x);
        if ((int)vals.size() != 2 * k) {
            throw runtime_error("Malformed line in shapes file: " + line);
        }
        Shape sh;
        sh.reserve(k);
        for (int i = 0; i < k; ++i) {
            int px = vals[2*i];
            int py = vals[2*i+1];
            sh.push_back({px, py});
        }
        if (k > maxSizeFound) maxSizeFound = k;
        if ((int)by_size.size() <= k) by_size.resize(k+1);
        by_size[k].push_back(std::move(sh));
    }

    // shrink to maxSizeFound
    if ((int)by_size.size() > maxSizeFound + 1) {
        by_size.resize(maxSizeFound + 1);
    }
    return by_size;
}

// ---------- Sampling helpers ----------

int sample_cell_cap(mt19937_64 &rng) {
    uniform_real_distribution<double> dist(2.0, 5.0);
    double p = dist(rng);
    double val = pow(10.0, p);
    int C = (int)llround(val);
    return max(1, C);
}

struct CaseInfo {
    string in_path;
    string ans_path;
    int k_pick;
    int k_use;
    int n;
    int pool_sz;
    int C_target;
    int C_hit;
};

CaseInfo write_case(
    int idx,
    const string &outdir,
    const vector<vector<Shape>> &hf_by_size,
    mt19937_64 &rng,
    int maxSizeUse
) {
    uniform_int_distribution<int> kdist(6, 15);
    int k_pick = kdist(rng);
    int k_use = min(k_pick, maxSizeUse);

    vector<const Shape*> pool;
    for (int s = 1; s <= k_use; ++s) {
        if (s >= (int)hf_by_size.size()) break;
        for (const auto &sh : hf_by_size[s]) {
            pool.push_back(&sh);
        }
    }
    if (pool.empty()) {
        throw runtime_error("Shape pool is empty; check shapes file or maxSizeUse.");
    }

    int C_target = sample_cell_cap(rng);
    vector<const Shape*> chosen;
    int total_cells = 0;

    uniform_int_distribution<size_t> pick_dist(0, pool.size() - 1);
    while (total_cells < C_target) {
        const Shape* poly = pool[pick_dist(rng)];
        chosen.push_back(poly);
        total_cells += (int)poly->size();
    }

    int n = (int)chosen.size();
    string in_path  = outdir + "/" + to_string(idx) + ".in";
    string ans_path = outdir + "/" + to_string(idx) + ".ans";

    {
        ofstream fout(in_path);
        if (!fout) {
            throw runtime_error("Failed to open " + in_path + " for writing");
        }
        fout << n << "\n";
        for (const Shape* poly : chosen) {
            fout << poly->size() << "\n";
            for (auto &p : *poly) {
                fout << p.first << " " << p.second << "\n";
            }
        }
    }
    {
        ofstream fout(ans_path);
        if (!fout) {
            throw runtime_error("Failed to open " + ans_path + " for writing");
        }
        fout << "zzz\n";
    }

    CaseInfo info{in_path, ans_path, k_pick, k_use, n,
                  (int)pool.size(), C_target, total_cells};
    return info;
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    Args args;
    try {
        args = parse_args(argc, argv);
    } catch (const exception &e) {
        cerr << "Argument error: " << e.what() << "\n";
        return 1;
    }

    try {
        std::filesystem::create_directories(args.out);
    } catch (const std::exception &e) {
        cerr << "Failed to create output directory: " << e.what() << "\n";
        return 1;
    }

    cerr << "[info] reading shapes from " << args.shapes_file << "...\n";
    int maxSizeFound = 0;
    vector<vector<Shape>> hf_by_size;
    try {
        hf_by_size = read_poly_file(args.shapes_file, maxSizeFound);
    } catch (const exception &e) {
        cerr << "Error reading shapes: " << e.what() << "\n";
        return 1;
    }

    cerr << "[info] max size found in shapes file = " << maxSizeFound << "\n";

    long long total_pool = 0;
    for (int s = 1; s <= maxSizeFound; ++s) {
        if (s >= (int)hf_by_size.size()) break;
        total_pool += (long long)hf_by_size[s].size();
    }
    cerr << "[info] total hole-free shapes loaded = " << total_pool << "\n";

    int maxSizeUse = min(maxSizeFound, 15);  // clamp to 15 like original

    for (int i = 1; i <= args.count; ++i) {
        mt19937_64 rng(args.seed + i);
        CaseInfo info = write_case(i, args.out, hf_by_size, rng, maxSizeUse);

        cerr << "✔ wrote " << info.in_path << "  " << info.ans_path
             << "  | k_pick=" << info.k_pick << "→" << info.k_use
             << ", n=" << info.n
             << ", |pool|=" << info.pool_sz
             << ", cells_target=" << info.C_target
             << ", cells_emitted=" << info.C_hit
             << "\n";
    }

    return 0;
}
